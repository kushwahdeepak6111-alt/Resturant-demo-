// Import high-resolution bespoke photography assets
import heroDiningImg from '../assets/images/hero_dining_1792222363580.jpg';
import storyInteriorImg from '../assets/images/story_interior_1792222388856.jpg';
import dishWagyuImg from '../assets/images/dish_wagyu_1792222412493.jpg';
import dishPastaImg from '../assets/images/dish_pasta_1792222430284.jpg';
import dishSalmonImg from '../assets/images/dish_salmon_1792222448008.jpg';
import dishLavaCakeImg from '../assets/images/dish_lava_cake_1792222472977.jpg';
import galleryCocktailImg from '../assets/images/gallery_cocktail_1792222489837.jpg';
import galleryAmbienceImg from '../assets/images/gallery_ambience_1792222534481.jpg';
import galleryPlatingImg from '../assets/images/gallery_plating_1792222552644.jpg';
import galleryWindowImg from '../assets/images/gallery_window_1792222508818.jpg';
import storySpicesImg from '../assets/images/story_spices_1792222577748.jpg';

export interface Dish {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: 'starters' | 'steaks' | 'pastas' | 'seafood' | 'desserts' | 'cocktails';
  featured?: boolean;
  dietary?: string[];
  pairing?: string;
  ingredients?: string[];
  chefNote?: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
}

export const RESTAURANT_INFO = {
  name: 'Ember & Spice',
  subline: 'RESTAURANT & LOUNGE',
  eyebrow: 'FINE DINING • CRAFTED COCKTAILS • UNFORGETTABLE MOMENTS',
  heroHeadlineLine1: 'Crafted Flavours.',
  heroHeadlineLine2: 'Memorable Moments.',
  heroDescription:
    'At Ember & Spice, we bring together the finest ingredients, expert chefs and a passion for great food. Experience a world of flavours, crafted just for you.',
  trustCount: '10,000+ food lovers',
  rating: '4.8/5',
  stars: 5,
  location: {
    address: '123 Gourmet Street',
    cityStateZip: 'Foodie City, FC 12345',
  },
  contact: {
    phone: '+1 (555) 123-4567',
    hours: 'Mon – Sun, 10:00 AM – 11:00 PM',
    email: 'hello@emberandspice.com',
    emailResponse: "We'll get back to you soon.",
  },
  socials: [
    { name: 'Instagram', href: 'https://instagram.com' },
    { name: 'Facebook', href: 'https://facebook.com' },
    { name: 'Twitter', href: 'https://x.com' },
    { name: 'Pinterest', href: 'https://pinterest.com' },
  ],
};

export const POPULAR_DISHES: Dish[] = [
  {
    id: 'wagyu-steak',
    name: 'Wagyu Steak',
    description: 'Grilled to perfection with rosemary butter.',
    price: 32,
    image: dishWagyuImg,
    category: 'steaks',
    featured: true,
    dietary: ['Gluten-Free', 'Chef Selection'],
    pairing: 'Château Margaux 2018 Cabernet Sauvignon',
    ingredients: ['A5 Grade Wagyu Ribeye', 'Hand-churned Rosemary Butter', 'Blistered Vine Cherry Tomatoes', 'Maldon Flake Salt'],
    chefNote: 'Seared on 900-degree binchotan coals to seal juices, basted with cultured rosemary butter.',
  },
  {
    id: 'truffle-pasta',
    name: 'Truffle Pasta',
    description: 'Rich, creamy, unforgettable.',
    price: 24,
    image: dishPastaImg,
    category: 'pastas',
    featured: true,
    dietary: ['Vegetarian', 'House Specialty'],
    pairing: 'Barolo DOCG 2017 Nebbiolo',
    ingredients: ['Handmade Egg Tagliatelle', 'Norcia Black Winter Truffle', '24-Month Parmigiano Reggiano', 'Organic Cultured Cream'],
    chefNote: 'Tossed immediately in the pan with freshly shaved Perigord winter truffles for deep earthy aromatic warmth.',
  },
  {
    id: 'herb-crusted-salmon',
    name: 'Herb Crusted Salmon',
    description: 'Fresh, healthy, delicious.',
    price: 26,
    image: dishSalmonImg,
    category: 'seafood',
    featured: true,
    dietary: ['Gluten-Free Option', 'Sustainable Catch'],
    pairing: 'Chablis Premier Cru 2020 Chardonnay',
    ingredients: ['Wild Skuna Bay Salmon', 'Pistachio Herb Crust', 'Tender Green Asparagus', 'Meyer Lemon Beurre Blanc'],
    chefNote: 'Pan-seared on the skin for shatteringly crisp texture while retaining buttery tenderness inside.',
  },
  {
    id: 'chocolate-lava-cake',
    name: 'Chocolate Lava Cake',
    description: 'A sweet ending to your meal.',
    price: 12,
    image: dishLavaCakeImg,
    category: 'desserts',
    featured: true,
    dietary: ['Vegetarian', 'Artisan Dessert'],
    pairing: 'Taylor Fladgate 20 Year Tawny Port',
    ingredients: ['72% Valrhona Guanaja Chocolate', 'Madagascar Vanilla Bean Gelato', 'Wild Alpine Raspberries', '24K Edible Gold Dust'],
    chefNote: 'Baked to order with an unctuous molten core that flows effortlessly upon the first spoon break.',
  },
];

export const EXTENDED_MENU: Dish[] = [
  ...POPULAR_DISHES,
  {
    id: 'hokkaido-scallops',
    name: 'Seared Hokkaido Scallops',
    description: 'Cauliflower mousseline, pomegranate reduction, brown butter hazelnuts.',
    price: 28,
    image: galleryPlatingImg,
    category: 'starters',
    dietary: ['Gluten-Free', 'Ocean Reserve'],
    pairing: 'Domaine Leflaive Puligny-Montrachet',
    ingredients: ['Wild Diver Scallops', 'Silky Cauliflower Cream', 'Ruby Pomegranate Pearls', 'Roasted Hazelnuts'],
    chefNote: 'Caramelized to a golden crust in brown butter with sweet delicate centers.',
  },
  {
    id: 'smoked-old-fashioned',
    name: 'The Ember Smoked Old Fashioned',
    description: 'Small-batch Kentucky bourbon, aromatic bitters, smoked with toasted cinnamon quill.',
    price: 18,
    image: galleryCocktailImg,
    category: 'cocktails',
    dietary: ['Signature Cocktail'],
    pairing: 'Charcuterie & Dark Chocolate Pairings',
    ingredients: ['Woodford Reserve Bourbon', 'Angostura & Orange Bitters', 'Dehydrated Orange Wheel', 'Applewood Cold Smoke'],
    chefNote: 'Served under an aroma-trapping glass cloche unsealed tableside with aromatic cinnamon smoke.',
  },
  {
    id: 'rack-of-lamb',
    name: 'Colorado Herb-Roasted Lamb Rack',
    description: 'Dijon herb crust, potato fondant, glazed baby carrots, rosemary demi-glace.',
    price: 42,
    image: galleryPlatingImg,
    category: 'steaks',
    dietary: ['Chef Signature'],
    pairing: 'Brunello di Montalcino 2016',
    ingredients: ['Heritage Colorado Lamb', 'Fresh Garden Thyme & Rosemary', 'Slow-Confit Garlic Jus', 'Baby Heirloom Carrots'],
    chefNote: 'Roasted pink medium-rare and carved tableside with savory lamb jus reduction.',
  },
  {
    id: 'lobster-ravioli',
    name: 'Maine Lobster Ravioli',
    description: 'Handmade saffron dough, sweet lobster knuckle, saffron saffron bisque, caviar.',
    price: 36,
    image: dishPastaImg,
    category: 'pastas',
    dietary: ['House Pasta Specialty'],
    pairing: 'Sancerre Blanc 2021',
    ingredients: ['Sweet Maine Lobster', 'Kashmiri Saffron Bisque', 'Oscietra Caviar', 'Micro Tarragon'],
    chefNote: 'Stuffed with fresh sweet claw meat bound with mascarpone and finished with gentle warmth.',
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g-cocktail',
    title: 'Smoked Alchemy',
    category: 'Mixology',
    description: 'Bespoke cocktails crafted with artisanal spirits and cold wood smoke.',
    image: galleryCocktailImg,
  },
  {
    id: 'g-dining-hall',
    title: 'The Grand Hall',
    category: 'Ambience',
    description: 'Golden pendant chandeliers and intimate dark wood dining settings.',
    image: galleryAmbienceImg,
  },
  {
    id: 'g-plating',
    title: 'Culinary Precision',
    category: 'Gastronomy',
    description: 'Every plate is an artwork composed with seasonal organic ingredients.',
    image: galleryPlatingImg,
  },
  {
    id: 'g-skyline-window',
    title: 'Twilight Skyline Suite',
    category: 'Experience',
    description: 'Floor-to-ceiling panoramic views of the city at golden hour and dusk.',
    image: galleryWindowImg,
  },
];

export const ASSETS = {
  heroDining: heroDiningImg,
  storyInterior: storyInteriorImg,
  storySpices: storySpicesImg,
};
