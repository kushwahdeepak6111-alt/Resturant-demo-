import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { PopularDishes } from './components/PopularDishes';
import { StorySection } from './components/StorySection';
import { GallerySection } from './components/GallerySection';
import { Footer } from './components/Footer';
import { ReservationModal } from './components/ReservationModal';
import { MenuModal } from './components/MenuModal';
import { DishDetailModal } from './components/DishDetailModal';
import { VideoModal } from './components/VideoModal';
import { GalleryLightbox } from './components/GalleryLightbox';
import { SearchModal } from './components/SearchModal';
import { LegalModal } from './components/LegalModal';
import { Dish, GalleryItem, GALLERY_ITEMS } from './data/restaurantData';

export default function App() {
  const [reservationOpen, setReservationOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [videoOpen, setVideoOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedDish, setSelectedDish] = useState<Dish | null>(null);
  const [preselectedDishForBooking, setPreselectedDishForBooking] = useState<string | undefined>(undefined);
  const [activeLightboxItem, setActiveLightboxItem] = useState<GalleryItem | null>(null);
  const [legalModalType, setLegalModalType] = useState<'privacy' | 'terms' | null>(null);

  // Reservation handlers
  const handleOpenReservation = (dishName?: string) => {
    setPreselectedDishForBooking(dishName);
    setReservationOpen(true);
  };

  // Dish selection from cards or menu
  const handleSelectDish = (dish: Dish) => {
    setSelectedDish(dish);
  };

  const handleBookDish = (dish: Dish) => {
    handleOpenReservation(dish.name);
  };

  // Gallery lightbox navigation
  const handleNextLightbox = () => {
    if (!activeLightboxItem) return;
    const currentIndex = GALLERY_ITEMS.findIndex((item) => item.id === activeLightboxItem.id);
    const nextIndex = (currentIndex + 1) % GALLERY_ITEMS.length;
    setActiveLightboxItem(GALLERY_ITEMS[nextIndex]);
  };

  const handlePrevLightbox = () => {
    if (!activeLightboxItem) return;
    const currentIndex = GALLERY_ITEMS.findIndex((item) => item.id === activeLightboxItem.id);
    const prevIndex = (currentIndex - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length;
    setActiveLightboxItem(GALLERY_ITEMS[prevIndex]);
  };

  return (
    <div className="min-h-screen bg-[#080807] text-[#F5F0E8] font-sans antialiased relative selection:bg-[#B88B47]/30">
      
      {/* 1. Luxury Navigation Header */}
      <Navbar
        onOpenReservation={() => handleOpenReservation()}
        onOpenSearch={() => setSearchOpen(true)}
        onOpenMenu={() => setMenuOpen(true)}
      />

      {/* Main Content Layout */}
      <main id="main-content">
        {/* 2. Large Cinematic Hero with Left Text & Right Dining Scene */}
        <Hero
          onOpenMenu={() => setMenuOpen(true)}
          onOpenReservation={() => handleOpenReservation()}
          onOpenVideo={() => setVideoOpen(true)}
        />

        {/* 3. Popular Dishes Section with 4 Cards & View Full Menu */}
        <PopularDishes
          onOpenMenu={() => setMenuOpen(true)}
          onSelectDish={handleSelectDish}
        />

        {/* 4. Split-Screen Restaurant Story Section */}
        <StorySection
          onOpenVideo={() => setVideoOpen(true)}
          onOpenReservation={() => handleOpenReservation()}
        />

        {/* 5. Gallery Section with Editorial Intro & Photographic Tiles */}
        <GallerySection
          onOpenLightbox={(item) => setActiveLightboxItem(item)}
          onOpenAllGallery={() => setActiveLightboxItem(GALLERY_ITEMS[0])}
        />
      </main>

      {/* 6. Multi-Column Contact & Newsletter Footer & 7. Legal Navigation */}
      <Footer
        onOpenPrivacy={() => setLegalModalType('privacy')}
        onOpenTerms={() => setLegalModalType('terms')}
      />

      {/* Interactive Overlays and Modals */}
      <ReservationModal
        isOpen={reservationOpen}
        onClose={() => {
          setReservationOpen(false);
          setPreselectedDishForBooking(undefined);
        }}
        preselectedDish={preselectedDishForBooking}
      />

      <MenuModal
        isOpen={menuOpen}
        onClose={() => setMenuOpen(false)}
        onSelectDish={handleSelectDish}
        onReserveWithDish={(dish) => handleOpenReservation(dish.name)}
      />

      <DishDetailModal
        dish={selectedDish}
        onClose={() => setSelectedDish(null)}
        onBookDish={handleBookDish}
      />

      <VideoModal
        isOpen={videoOpen}
        onClose={() => setVideoOpen(false)}
        onOpenReservation={() => handleOpenReservation()}
      />

      <GalleryLightbox
        activeItem={activeLightboxItem}
        onClose={() => setActiveLightboxItem(null)}
        onSelectNext={handleNextLightbox}
        onSelectPrev={handlePrevLightbox}
        onBookExperience={() => handleOpenReservation()}
      />

      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectDish={handleSelectDish}
        onOpenReservation={() => handleOpenReservation()}
      />

      <LegalModal
        type={legalModalType}
        onClose={() => setLegalModalType(null)}
      />

    </div>
  );
}
