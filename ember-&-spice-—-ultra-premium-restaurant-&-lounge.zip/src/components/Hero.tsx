import React from 'react';
import { ArrowRight, Calendar, Play, Star } from 'lucide-react';
import { RESTAURANT_INFO, ASSETS } from '../data/restaurantData';

interface HeroProps {
  onOpenMenu: () => void;
  onOpenReservation: () => void;
  onOpenVideo: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onOpenMenu,
  onOpenReservation,
  onOpenVideo,
}) => {
  return (
    <section
      id="home"
      className="relative min-h-[92vh] lg:min-h-screen flex items-center bg-[#080807] overflow-hidden pt-24 pb-16 lg:py-0 border-b border-[#79603A]/25"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#D4AD68]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-[#B88B47]/8 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Text Column (5 to 6 cols) */}
          <div className="lg:col-span-6 xl:col-span-5 pt-8 lg:pt-0">
            {/* Small uppercase gold eyebrow */}
            <div className="inline-flex items-center gap-2 mb-4">
              <span className="text-[10px] sm:text-xs font-medium uppercase tracking-[0.25em] text-[#D4AD68]">
                {RESTAURANT_INFO.eyebrow}
              </span>
            </div>

            {/* Large elegant headline with upright line 1 and champagne italic line 2 */}
            <h1 className="text-4xl sm:text-5xl xl:text-6xl font-serif font-normal leading-[1.08] tracking-tight text-[#F5F0E8] mb-6">
              <span>{RESTAURANT_INFO.heroHeadlineLine1}</span>
              <br />
              <span className="italic text-[#D4AD68] font-normal font-serif">
                {RESTAURANT_INFO.heroHeadlineLine2}
              </span>
            </h1>

            {/* Short supporting paragraph */}
            <p className="text-sm sm:text-base text-[#C5BFB5] leading-relaxed max-w-lg mb-8 font-light">
              {RESTAURANT_INFO.heroDescription}
            </p>

            {/* Two Refined Call-to-Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-10">
              {/* Primary: Champagne gold fill with dark contrast text and right arrow */}
              <button
                onClick={onOpenMenu}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 bg-[#D4AD68] hover:bg-[#B88B47] text-[#080807] font-medium text-xs sm:text-sm tracking-wider uppercase rounded-full shadow-lg shadow-[#D4AD68]/15 hover:shadow-[#D4AD68]/25 transition-all duration-300 hover:translate-x-0.5 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F5F0E8]"
              >
                <span>Explore Our Menu</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Secondary: Dark pill with thin gold outline and calendar icon */}
              <button
                onClick={onOpenReservation}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-[#10100F]/80 hover:bg-[#10100F] border border-[#B88B47]/60 hover:border-[#D4AD68] text-[#F5F0E8] font-medium text-xs sm:text-sm tracking-wider uppercase rounded-full transition-all duration-300 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AD68]"
              >
                <span>Book a Table</span>
                <Calendar className="w-4 h-4 text-[#D4AD68]" />
              </button>
            </div>

            {/* Social Proof & Trust Badges */}
            <div className="flex items-center gap-4 pt-2 border-t border-[#79603A]/20">
              {/* Overlapping customer avatars */}
              <div className="flex -space-x-2 overflow-hidden">
                <img
                  className="inline-block h-9 w-9 rounded-full ring-2 ring-[#080807] object-cover"
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&h=120&q=80"
                  alt="Guest avatar"
                  loading="lazy"
                />
                <img
                  className="inline-block h-9 w-9 rounded-full ring-2 ring-[#080807] object-cover"
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&h=120&q=80"
                  alt="Guest avatar"
                  loading="lazy"
                />
                <img
                  className="inline-block h-9 w-9 rounded-full ring-2 ring-[#080807] object-cover"
                  src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=120&h=120&q=80"
                  alt="Guest avatar"
                  loading="lazy"
                />
                <img
                  className="inline-block h-9 w-9 rounded-full ring-2 ring-[#080807] object-cover"
                  src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&h=120&q=80"
                  alt="Guest avatar"
                  loading="lazy"
                />
              </div>

              {/* Rating and review count */}
              <div className="flex flex-col">
                <span className="text-xs text-[#C5BFB5] font-light">
                  Trusted by <strong className="font-semibold text-[#F5F0E8]">{RESTAURANT_INFO.trustCount}</strong>
                </span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <div className="flex text-[#D4AD68]" aria-hidden="true">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-[#D4AD68]" />
                    ))}
                  </div>
                  <span className="text-xs font-medium text-[#F5F0E8]">{RESTAURANT_INFO.rating}</span>
                </div>
              </div>
            </div>

          </div>

          {/* Right Main Photographic Hero Scene (7 cols) */}
          <div className="lg:col-span-6 xl:col-span-7 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#79603A]/30 shadow-2xl bg-[#10100F] group">
              {/* Subtle top and left vignette overlay for seamless blend */}
              <div className="absolute inset-0 bg-gradient-to-tr from-[#080807]/60 via-transparent to-black/20 z-10 pointer-events-none" />
              
              <img
                src={ASSETS.heroDining}
                alt="Ember & Spice signature grilled Wagyu tomahawk steak with wine, candle and night city view"
                className="w-full h-[380px] sm:h-[460px] lg:h-[560px] object-cover object-center transition-transform duration-700 group-hover:scale-[1.02]"
              />

              {/* Gold border accent line at the bottom */}
              <div className="absolute bottom-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-[#D4AD68]/40 to-transparent z-20" />

              {/* Floating "Watch Our Story" button at bottom right */}
              <div className="absolute bottom-5 right-5 sm:bottom-6 sm:right-6 z-20">
                <button
                  onClick={onOpenVideo}
                  className="flex items-center gap-3 px-4 py-2.5 rounded-full bg-[#080807]/80 hover:bg-[#080807] border border-[#B88B47]/60 hover:border-[#D4AD68] backdrop-blur-md transition-all duration-300 group/btn cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                  aria-label="Watch our restaurant story video"
                >
                  <div className="w-7 h-7 rounded-full bg-[#D4AD68]/20 flex items-center justify-center border border-[#D4AD68] group-hover/btn:bg-[#D4AD68] transition-colors">
                    <Play className="w-3 h-3 text-[#D4AD68] group-hover/btn:text-[#080807] fill-current translate-x-0.5" />
                  </div>
                  <span className="text-xs uppercase font-medium tracking-widest text-[#F5F0E8] group-hover/btn:text-[#D4AD68] transition-colors">
                    Watch Our Story
                  </span>
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
