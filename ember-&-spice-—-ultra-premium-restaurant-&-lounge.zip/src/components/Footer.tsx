import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Instagram,
  Facebook,
  Twitter,
  ArrowRight,
  ArrowUp,
  CheckCircle,
} from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';
import { validateEmail } from '../utils/booking';

interface FooterProps {
  onOpenPrivacy: () => void;
  onOpenTerms: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenPrivacy,
  onOpenTerms,
}) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [newsletterError, setNewsletterError] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateEmail(newsletterEmail)) {
      setNewsletterError('Please enter a valid email address');
      return;
    }
    setNewsletterError('');
    setSubscribed(true);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="contact" className="bg-[#050505] text-[#C5BFB5] border-t border-[#79603A]/30">
      {/* Main Multi-Column Contact Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 items-start">
          
          {/* 1. Location */}
          <div className="lg:col-span-3 flex items-start gap-3.5">
            <div className="w-8 h-8 rounded-full border border-[#D4AD68]/40 flex items-center justify-center text-[#D4AD68] shrink-0 mt-0.5">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-medium text-[#F5F0E8] mb-1">Location</h4>
              <p className="text-xs text-[#938C81] leading-relaxed">
                {RESTAURANT_INFO.location.address}
                <br />
                {RESTAURANT_INFO.location.cityStateZip}
              </p>
            </div>
          </div>

          {/* 2. Call Us */}
          <div className="lg:col-span-3 flex items-start gap-3.5">
            <div className="w-8 h-8 rounded-full border border-[#D4AD68]/40 flex items-center justify-center text-[#D4AD68] shrink-0 mt-0.5">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-medium text-[#F5F0E8] mb-1">Call Us</h4>
              <p className="text-xs text-[#938C81] leading-relaxed">
                <a
                  href={`tel:${RESTAURANT_INFO.contact.phone}`}
                  className="hover:text-[#D4AD68] transition-colors font-medium text-[#C5BFB5]"
                >
                  {RESTAURANT_INFO.contact.phone}
                </a>
                <br />
                {RESTAURANT_INFO.contact.hours}
              </p>
            </div>
          </div>

          {/* 3. Email Us */}
          <div className="lg:col-span-2 flex items-start gap-3.5">
            <div className="w-8 h-8 rounded-full border border-[#D4AD68]/40 flex items-center justify-center text-[#D4AD68] shrink-0 mt-0.5">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-medium text-[#F5F0E8] mb-1">Email Us</h4>
              <p className="text-xs text-[#938C81] leading-relaxed">
                <a
                  href={`mailto:${RESTAURANT_INFO.contact.email}`}
                  className="hover:text-[#D4AD68] transition-colors text-[#C5BFB5]"
                >
                  {RESTAURANT_INFO.contact.email}
                </a>
                <br />
                {RESTAURANT_INFO.contact.emailResponse}
              </p>
            </div>
          </div>

          {/* 4. Follow Us & Newsletter (lg:col-span-4) */}
          <div className="lg:col-span-4 flex flex-col space-y-6">
            {/* Social Icons */}
            <div>
              <h4 className="text-sm font-medium text-[#F5F0E8] mb-2.5">Follow Us</h4>
              <div className="flex items-center space-x-3">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] transition-colors"
                  aria-label="Follow Ember & Spice on Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] transition-colors"
                  aria-label="Follow Ember & Spice on Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </a>
                <a
                  href="https://x.com"
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] transition-colors"
                  aria-label="Follow Ember & Spice on Twitter"
                >
                  <Twitter className="w-4 h-4" />
                </a>
                <a
                  href="https://pinterest.com"
                  target="_blank"
                  rel="noreferrer"
                  className="w-8 h-8 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] transition-colors"
                  aria-label="Follow Ember & Spice on Pinterest"
                >
                  <span className="font-serif text-sm font-semibold">P</span>
                </a>
              </div>
            </div>

            {/* Newsletter Input */}
            <div>
              <h4 className="text-sm font-medium text-[#F5F0E8] mb-1">Join Our Newsletter</h4>
              <p className="text-xs text-[#938C81] mb-2.5">Get exclusive offers &amp; updates.</p>

              {subscribed ? (
                <div className="flex items-center gap-2 text-xs text-[#D4AD68] bg-[#10100F] border border-[#D4AD68]/40 px-3 py-2.5 rounded-full">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <span>Welcome to the Ember &amp; Spice inner circle.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="relative max-w-sm">
                  <input
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Your email address"
                    className="w-full bg-[#10100F] border border-[#79603A]/50 focus:border-[#D4AD68] text-xs text-[#F5F0E8] placeholder-[#79603A] rounded-full py-2.5 pl-4 pr-11 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68] transition-all"
                  />
                  <button
                    type="submit"
                    className="absolute right-1 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-[#D4AD68] hover:bg-[#B88B47] text-[#080807] flex items-center justify-center transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#F5F0E8]"
                    aria-label="Submit newsletter subscription"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  {newsletterError && (
                    <p className="text-[11px] text-red-400 mt-1 pl-3">{newsletterError}</p>
                  )}
                </form>
              )}
            </div>

          </div>

        </div>
      </div>

      {/* Minimal Copyright and Legal Navigation Row */}
      <div className="border-t border-[#79603A]/20 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#938C81]">
          <p>© 2026 Ember &amp; Spice. All rights reserved.</p>

          <div className="flex items-center space-x-6">
            <button
              onClick={onOpenPrivacy}
              className="hover:text-[#D4AD68] transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <span className="text-[#79603A]">·</span>
            <button
              onClick={onOpenTerms}
              className="hover:text-[#D4AD68] transition-colors cursor-pointer"
            >
              Terms &amp; Conditions
            </button>
          </div>

          {/* Back to top control */}
          <button
            onClick={scrollToTop}
            className="w-8 h-8 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] hover:bg-[#10100F] transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
            aria-label="Scroll back to top of page"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};
