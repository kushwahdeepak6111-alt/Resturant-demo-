import React, { useState } from 'react';
import { X, Calendar, Clock, Users, Sparkles, CheckCircle2, Copy, Check } from 'lucide-react';
import {
  ReservationRequest,
  validateReservation,
  generateBookingReference,
  formatReservationDateTime,
} from '../utils/booking';

interface ReservationModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedDish?: string;
}

const SEATING_OPTIONS = [
  { id: 'skyline', name: 'Skyline Window Table', desc: 'Floor-to-ceiling panoramic city views' },
  { id: 'main', name: 'Main Dining Room', desc: 'Warm chandelier ambiance & fireplace' },
  { id: 'chef', name: "Chef's Counter", desc: 'Intimate front-row culinary spectacle' },
  { id: 'lounge', name: 'Private Velvet Lounge', desc: 'Discreet low-lit booth seating' },
] as const;

const TIME_SLOTS = [
  '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30',
];

export const ReservationModal: React.FC<ReservationModalProps> = ({
  isOpen,
  onClose,
  preselectedDish,
}) => {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const defaultDate = tomorrow.toISOString().split('T')[0];

  const [formData, setFormData] = useState<ReservationRequest>({
    date: defaultDate,
    time: '19:30',
    guests: 2,
    seatingArea: 'skyline',
    fullName: '',
    email: '',
    phone: '',
    specialRequests: preselectedDish ? `Interested in pairing with: ${preselectedDish}` : '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirmedBooking, setConfirmedBooking] = useState<{
    reference: string;
    date: string;
    time: string;
    guests: number;
    seatingName: string;
    name: string;
  } | null>(null);

  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = validateReservation(formData);
    if (!result.isValid) {
      setErrors(result.errors);
      return;
    }

    setErrors({});
    const ref = generateBookingReference();
    const seatingOption = SEATING_OPTIONS.find((s) => s.id === formData.seatingArea);

    setConfirmedBooking({
      reference: ref,
      date: formData.date,
      time: formData.time,
      guests: formData.guests,
      seatingName: seatingOption?.name || 'Main Dining Room',
      name: formData.fullName,
    });
  };

  const copyReference = () => {
    if (confirmedBooking) {
      navigator.clipboard.writeText(confirmedBooking.reference);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const resetForm = () => {
    setConfirmedBooking(null);
    setFormData({
      date: defaultDate,
      time: '19:30',
      guests: 2,
      seatingArea: 'skyline',
      fullName: '',
      email: '',
      phone: '',
      specialRequests: '',
    });
    setErrors({});
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="reservation-modal-title"
    >
      <div className="relative w-full max-w-2xl bg-[#10100F] border border-[#79603A]/50 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#79603A]/25 bg-[#080807]">
          <div>
            <span className="text-[10px] font-medium tracking-[0.25em] text-[#D4AD68] uppercase block">
              TABLE RESERVATION
            </span>
            <h2
              id="reservation-modal-title"
              className="text-2xl font-serif font-normal text-[#F5F0E8] mt-0.5"
            >
              Reserve Your Experience
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full border border-[#79603A]/40 flex items-center justify-center text-[#C5BFB5] hover:text-[#F5F0E8] hover:border-[#D4AD68] transition-colors focus-visible:outline-none"
            aria-label="Close reservation dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {confirmedBooking ? (
            <div className="py-6 text-center space-y-6 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-[#D4AD68]/15 border border-[#D4AD68] flex items-center justify-center text-[#D4AD68] mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs uppercase tracking-widest text-[#D4AD68]">
                  Table Confirmed
                </span>
                <h3 className="text-3xl font-serif text-[#F5F0E8] mt-1">
                  We look forward to welcoming you, {confirmedBooking.name}
                </h3>
                <p className="text-sm text-[#C5BFB5] font-light mt-2 max-w-md mx-auto">
                  A personalized confirmation email has been dispatched with concierge arrival notes and sommelier recommendations.
                </p>
              </div>

              {/* Booking Summary Card */}
              <div className="bg-[#080807] border border-[#79603A]/40 rounded-xl p-5 max-w-md mx-auto text-left space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-[#79603A]/25">
                  <span className="text-xs text-[#938C81]">Booking Reference</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm text-[#D4AD68] font-semibold tracking-wider">
                      {confirmedBooking.reference}
                    </span>
                    <button
                      onClick={copyReference}
                      className="text-[#C5BFB5] hover:text-[#D4AD68] p-1 transition-colors"
                      aria-label="Copy booking reference code"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs pt-1">
                  <div>
                    <span className="text-[#938C81] block">Date &amp; Time</span>
                    <span className="text-[#F5F0E8] font-medium mt-0.5 block">
                      {formatReservationDateTime(confirmedBooking.date, confirmedBooking.time)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#938C81] block">Party Size</span>
                    <span className="text-[#F5F0E8] font-medium mt-0.5 block">
                      {confirmedBooking.guests} {confirmedBooking.guests === 1 ? 'Guest' : 'Guests'}
                    </span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[#938C81] block">Seating Setting</span>
                    <span className="text-[#D4AD68] font-medium mt-0.5 block">
                      {confirmedBooking.seatingName}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center gap-4 pt-2">
                <button
                  onClick={resetForm}
                  className="px-5 py-2.5 rounded-full border border-[#79603A]/60 hover:border-[#D4AD68] text-xs font-medium text-[#F5F0E8] tracking-wider uppercase transition-colors"
                >
                  Book Another Table
                </button>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-full bg-[#D4AD68] hover:bg-[#B88B47] text-[#080807] text-xs font-medium tracking-wider uppercase transition-colors"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Step 1: Seating Setting Selection */}
              <div>
                <label className="text-xs uppercase tracking-wider text-[#D4AD68] font-medium block mb-3">
                  1. Select Seating Setting
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {SEATING_OPTIONS.map((option) => {
                    const isSelected = formData.seatingArea === option.id;
                    return (
                      <button
                        type="button"
                        key={option.id}
                        onClick={() => setFormData({ ...formData, seatingArea: option.id })}
                        className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#1a1815] border-[#D4AD68] shadow-md shadow-[#D4AD68]/10'
                            : 'bg-[#080807] border-[#79603A]/30 hover:border-[#79603A]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span
                            className={`text-sm font-medium ${
                              isSelected ? 'text-[#D4AD68]' : 'text-[#F5F0E8]'
                            }`}
                          >
                            {option.name}
                          </span>
                          {isSelected && <Sparkles className="w-3.5 h-3.5 text-[#D4AD68]" />}
                        </div>
                        <p className="text-[11px] text-[#938C81]">{option.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Date, Time & Guests */}
              <div>
                <label className="text-xs uppercase tracking-wider text-[#D4AD68] font-medium block mb-3">
                  2. Date, Time &amp; Party Size
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Date */}
                  <div>
                    <label htmlFor="res-date" className="text-xs text-[#938C81] block mb-1 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#D4AD68]" />
                      Date
                    </label>
                    <input
                      id="res-date"
                      type="date"
                      value={formData.date}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="w-full bg-[#080807] border border-[#79603A]/40 focus:border-[#D4AD68] rounded-lg px-3 py-2 text-xs text-[#F5F0E8] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                    />
                    {errors.date && <p className="text-[11px] text-red-400 mt-1">{errors.date}</p>}
                  </div>

                  {/* Guests */}
                  <div>
                    <label htmlFor="res-guests" className="text-xs text-[#938C81] block mb-1 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-[#D4AD68]" />
                      Party Size
                    </label>
                    <select
                      id="res-guests"
                      value={formData.guests}
                      onChange={(e) => setFormData({ ...formData, guests: parseInt(e.target.value, 10) })}
                      className="w-full bg-[#080807] border border-[#79603A]/40 focus:border-[#D4AD68] rounded-lg px-3 py-2 text-xs text-[#F5F0E8] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12].map((num) => (
                        <option key={num} value={num}>
                          {num} {num === 1 ? 'Guest' : 'Guests'}
                        </option>
                      ))}
                    </select>
                    {errors.guests && <p className="text-[11px] text-red-400 mt-1">{errors.guests}</p>}
                  </div>

                  {/* Time */}
                  <div>
                    <label htmlFor="res-time" className="text-xs text-[#938C81] block mb-1 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#D4AD68]" />
                      Seating Time
                    </label>
                    <select
                      id="res-time"
                      value={formData.time}
                      onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                      className="w-full bg-[#080807] border border-[#79603A]/40 focus:border-[#D4AD68] rounded-lg px-3 py-2 text-xs text-[#F5F0E8] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                    >
                      {TIME_SLOTS.map((slot) => (
                        <option key={slot} value={slot}>
                          {slot}
                        </option>
                      ))}
                    </select>
                    {errors.time && <p className="text-[11px] text-red-400 mt-1">{errors.time}</p>}
                  </div>
                </div>
              </div>

              {/* Step 3: Contact Details */}
              <div>
                <label className="text-xs uppercase tracking-wider text-[#D4AD68] font-medium block mb-3">
                  3. Contact Information
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="res-name" className="text-xs text-[#938C81] block mb-1">
                      Full Name *
                    </label>
                    <input
                      id="res-name"
                      type="text"
                      placeholder="e.g. Julian Montgomery"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full bg-[#080807] border border-[#79603A]/40 focus:border-[#D4AD68] rounded-lg px-3 py-2 text-xs text-[#F5F0E8] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                    />
                    {errors.fullName && <p className="text-[11px] text-red-400 mt-1">{errors.fullName}</p>}
                  </div>

                  <div>
                    <label htmlFor="res-email" className="text-xs text-[#938C81] block mb-1">
                      Email Address *
                    </label>
                    <input
                      id="res-email"
                      type="email"
                      placeholder="julian@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-[#080807] border border-[#79603A]/40 focus:border-[#D4AD68] rounded-lg px-3 py-2 text-xs text-[#F5F0E8] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                    />
                    {errors.email && <p className="text-[11px] text-red-400 mt-1">{errors.email}</p>}
                  </div>

                  <div className="sm:col-span-2">
                    <label htmlFor="res-phone" className="text-xs text-[#938C81] block mb-1">
                      Phone Number *
                    </label>
                    <input
                      id="res-phone"
                      type="tel"
                      placeholder="+1 (555) 000-0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full bg-[#080807] border border-[#79603A]/40 focus:border-[#D4AD68] rounded-lg px-3 py-2 text-xs text-[#F5F0E8] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                    />
                    {errors.phone && <p className="text-[11px] text-red-400 mt-1">{errors.phone}</p>}
                  </div>

                  <div className="sm:col-span-2">
                    <label htmlFor="res-notes" className="text-xs text-[#938C81] block mb-1">
                      Dietary Notes or Special Occasion (Optional)
                    </label>
                    <textarea
                      id="res-notes"
                      rows={2}
                      placeholder="e.g. Celebrating 10th anniversary, gluten allergy, champagne request..."
                      value={formData.specialRequests}
                      onChange={(e) => setFormData({ ...formData, specialRequests: e.target.value })}
                      className="w-full bg-[#080807] border border-[#79603A]/40 focus:border-[#D4AD68] rounded-lg px-3 py-2 text-xs text-[#F5F0E8] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                    />
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#D4AD68] hover:bg-[#B88B47] text-[#080807] text-xs font-semibold uppercase tracking-widest rounded-full shadow-lg shadow-[#D4AD68]/15 hover:shadow-[#D4AD68]/25 transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F5F0E8]"
                >
                  Confirm Reservation
                </button>
              </div>

            </form>
          )}
        </div>
      </div>
    </div>
  );
};
