import React, { useRef } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, Maximize2 } from 'lucide-react';
import { GALLERY_ITEMS, GalleryItem } from '../data/restaurantData';

interface GallerySectionProps {
  onOpenLightbox: (item: GalleryItem) => void;
  onOpenAllGallery: () => void;
}

export const GallerySection: React.FC<GallerySectionProps> = ({
  onOpenLightbox,
  onOpenAllGallery,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const offset = direction === 'left' ? -320 : 320;
      scrollContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  return (
    <section
      id="gallery"
      className="py-20 lg:py-24 bg-[#080807] border-b border-[#79603A]/25 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Row */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-12 gap-6">
          <div className="max-w-xl">
            <span className="text-[10px] sm:text-xs font-medium uppercase tracking-[0.25em] text-[#D4AD68] block mb-2">
              GALLERY
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#F5F0E8] tracking-tight mb-3">
              A Taste of Our World
            </h2>
            <p className="text-sm sm:text-base text-[#C5BFB5] font-light leading-relaxed mb-6">
              Explore the moments, flavours and ambience that make Ember &amp; Spice special.
            </p>

            <button
              onClick={onOpenAllGallery}
              className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full border border-[#B88B47]/60 hover:border-[#D4AD68] text-xs font-medium uppercase tracking-wider text-[#F5F0E8] hover:bg-[#D4AD68]/10 transition-all duration-300 group cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
            >
              <span>View Gallery</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#D4AD68] transition-transform duration-200 group-hover:translate-x-1" />
            </button>
          </div>

          {/* Carousel Arrows on top right */}
          <div className="flex items-center gap-3 self-end lg:self-auto">
            <button
              onClick={() => scroll('left')}
              className="w-10 h-10 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] hover:bg-[#10100F] transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
              aria-label="Previous gallery images"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="w-10 h-10 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] hover:bg-[#10100F] transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
              aria-label="Next gallery images"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 4 Photographic Tiles */}
        <div
          ref={scrollContainerRef}
          className="flex lg:grid lg:grid-cols-4 gap-5 overflow-x-auto lg:overflow-visible pb-4 lg:pb-0 scrollbar-none snap-x snap-mandatory"
        >
          {GALLERY_ITEMS.map((item) => (
            <div
              key={item.id}
              onClick={() => onOpenLightbox(item)}
              className="min-w-[270px] sm:min-w-[290px] lg:min-w-0 snap-start relative aspect-[4/3] rounded-xl overflow-hidden border border-[#79603A]/30 hover:border-[#D4AD68]/70 bg-[#10100F] group cursor-pointer shadow-lg transition-all duration-300"
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onOpenLightbox(item);
                }
              }}
              aria-label={`Open photo of ${item.title}`}
            >
              <img
                src={item.image}
                alt={item.title}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-108"
              />

              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              {/* Hover icon */}
              <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 border border-[#D4AD68]/60 flex items-center justify-center text-[#D4AD68] opacity-0 group-hover:opacity-100 transition-opacity">
                <Maximize2 className="w-3.5 h-3.5" />
              </div>

              {/* Content caption at bottom */}
              <div className="absolute bottom-4 left-4 right-4 z-10">
                <span className="text-[10px] uppercase tracking-widest text-[#D4AD68] font-medium block">
                  {item.category}
                </span>
                <h3 className="text-base font-serif text-[#F5F0E8] mt-0.5 group-hover:text-[#D4AD68] transition-colors">
                  {item.title}
                </h3>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
