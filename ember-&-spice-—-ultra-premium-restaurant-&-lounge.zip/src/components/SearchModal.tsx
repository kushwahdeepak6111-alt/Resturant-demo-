import React, { useState, useMemo } from 'react';
import { X, Search, ArrowRight, Utensils, Wine, Clock } from 'lucide-react';
import { EXTENDED_MENU, Dish } from '../data/restaurantData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDish: (dish: Dish) => void;
  onOpenReservation: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectDish,
  onOpenReservation,
}) => {
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return EXTENDED_MENU.filter(
      (item) =>
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        (item.pairing && item.pairing.toLowerCase().includes(q)) ||
        (item.ingredients && item.ingredients.some((i) => i.toLowerCase().includes(q)))
    );
  }, [query]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="search-modal-title"
    >
      <div className="relative w-full max-w-2xl bg-[#10100F] border border-[#79603A]/60 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* Search Input Bar */}
        <div className="p-4 bg-[#080807] border-b border-[#79603A]/30 flex items-center gap-3">
          <Search className="w-5 h-5 text-[#D4AD68] shrink-0" />
          <input
            id="search-modal-title"
            type="text"
            autoFocus
            placeholder="Search our cuisine, Wagyu, truffle, salmon, cocktails, wines..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm sm:text-base text-[#F5F0E8] placeholder-[#79603A] focus:outline-none"
          />
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full border border-[#79603A]/30 flex items-center justify-center text-[#C5BFB5] hover:text-[#F5F0E8] transition-colors"
            aria-label="Close search"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results or Suggested Queries */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-4">
          {!query.trim() ? (
            <div>
              <span className="text-[10px] uppercase tracking-widest text-[#938C81] block mb-3 font-medium">
                POPULAR SEARCHES
              </span>
              <div className="flex flex-wrap gap-2">
                {['Wagyu Ribeye', 'Black Truffle Tagliatelle', 'Skuna Bay Salmon', 'Old Fashioned', 'Valrhona Chocolate', 'Window Table'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => {
                      if (tag === 'Window Table') {
                        onClose();
                        onOpenReservation();
                      } else {
                        setQuery(tag);
                      }
                    }}
                    className="text-xs px-3 py-1.5 rounded-full bg-[#1a1815] border border-[#79603A]/30 hover:border-[#D4AD68] text-[#C5BFB5] hover:text-[#D4AD68] transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>

              <div className="mt-8 pt-6 border-t border-[#79603A]/20 flex items-center justify-between text-xs text-[#938C81]">
                <span className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-[#D4AD68]" />
                  Dinner Service: 5:00 PM – 11:00 PM Daily
                </span>
                <button
                  onClick={() => {
                    onClose();
                    onOpenReservation();
                  }}
                  className="text-[#D4AD68] hover:underline font-medium"
                >
                  Reserve a Table
                </button>
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="py-8 text-center text-[#938C81]">
              <Utensils className="w-8 h-8 mx-auto mb-2 text-[#79603A]" />
              <p className="text-sm">No dishes or pairings found matching &quot;{query}&quot;.</p>
              <p className="text-xs text-[#79603A] mt-1">Try searching for ingredients like &quot;truffle&quot;, &quot;steak&quot;, or &quot;cocktail&quot;.</p>
            </div>
          ) : (
            <div className="space-y-3">
              <span className="text-[10px] uppercase tracking-widest text-[#D4AD68] block font-medium">
                {results.length} CULINARY RESULTS
              </span>
              {results.map((dish) => (
                <div
                  key={dish.id}
                  onClick={() => {
                    onClose();
                    onSelectDish(dish);
                  }}
                  className="p-3 rounded-xl bg-[#080807] border border-[#79603A]/30 hover:border-[#D4AD68] flex items-center justify-between gap-4 cursor-pointer group transition-all"
                  role="button"
                  tabIndex={0}
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={dish.image}
                      alt={dish.name}
                      className="w-12 h-12 rounded-lg object-cover shrink-0"
                    />
                    <div>
                      <h4 className="text-sm font-serif text-[#F5F0E8] group-hover:text-[#D4AD68] transition-colors">
                        {dish.name}
                      </h4>
                      <p className="text-xs text-[#938C81] line-clamp-1">{dish.description}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-serif text-sm text-[#D4AD68] font-medium">
                      ${dish.price}
                    </span>
                    <ArrowRight className="w-4 h-4 text-[#79603A] group-hover:text-[#D4AD68] transition-colors" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
