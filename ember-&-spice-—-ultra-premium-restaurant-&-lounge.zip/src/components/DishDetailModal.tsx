import React from 'react';
import { X, Calendar, Wine, Utensils, Award } from 'lucide-react';
import { Dish } from '../data/restaurantData';

interface DishDetailModalProps {
  dish: Dish | null;
  onClose: () => void;
  onBookDish: (dish: Dish) => void;
}

export const DishDetailModal: React.FC<DishDetailModalProps> = ({
  dish,
  onClose,
  onBookDish,
}) => {
  if (!dish) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="dish-detail-title"
    >
      <div className="relative w-full max-w-2xl bg-[#10100F] border border-[#79603A]/50 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Close Button Floating */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-black/60 border border-[#79603A]/40 flex items-center justify-center text-[#C5BFB5] hover:text-[#F5F0E8] hover:border-[#D4AD68] transition-colors focus-visible:outline-none"
          aria-label="Close dish details"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Hero Dish Image */}
        <div className="relative h-64 sm:h-72 w-full bg-[#080807] shrink-0">
          <img
            src={dish.image}
            alt={dish.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#10100F] via-transparent to-black/30" />
          <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between">
            <div>
              <span className="text-[10px] uppercase tracking-[0.25em] text-[#D4AD68] font-semibold block">
                CHEF&apos;S CURATION
              </span>
              <h2 id="dish-detail-title" className="text-3xl font-serif text-[#F5F0E8] mt-1">
                {dish.name}
              </h2>
            </div>
            <span className="text-2xl font-serif text-[#D4AD68] font-medium">
              ${dish.price}
            </span>
          </div>
        </div>

        {/* Details Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          <p className="text-sm text-[#C5BFB5] leading-relaxed font-light">
            {dish.description}
          </p>

          {/* Sommelier Pairing & Chef Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {dish.pairing && (
              <div className="bg-[#080807] border border-[#79603A]/30 rounded-xl p-4 flex items-start gap-3">
                <Wine className="w-5 h-5 text-[#D4AD68] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#D4AD68] block font-medium">
                    Sommelier Pairing
                  </span>
                  <p className="text-xs text-[#F5F0E8] mt-1 leading-snug">
                    {dish.pairing}
                  </p>
                </div>
              </div>
            )}

            {dish.chefNote && (
              <div className="bg-[#080807] border border-[#79603A]/30 rounded-xl p-4 flex items-start gap-3">
                <Award className="w-5 h-5 text-[#D4AD68] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#D4AD68] block font-medium">
                    Chef&apos;s Technique
                  </span>
                  <p className="text-xs text-[#F5F0E8] mt-1 leading-snug">
                    {dish.chefNote}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Key Ingredients */}
          {dish.ingredients && dish.ingredients.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Utensils className="w-3.5 h-3.5 text-[#D4AD68]" />
                <span className="text-xs uppercase tracking-wider text-[#938C81] font-medium">
                  Artisanal Ingredients
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {dish.ingredients.map((ing, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-3 py-1 rounded-full bg-[#1a1815] border border-[#79603A]/30 text-[#C5BFB5]"
                  >
                    {ing}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Bottom Action */}
          <div className="pt-2 flex items-center justify-between border-t border-[#79603A]/20">
            <span className="text-xs text-[#938C81]">
              Prepared fresh to order in our culinary fire hearth.
            </span>

            <button
              onClick={() => {
                onClose();
                onBookDish(dish);
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#D4AD68] hover:bg-[#B88B47] text-[#080807] text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Reserve Table for This Dish</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
