import React, { useState } from 'react';
import { X, Play, Pause, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { ASSETS } from '../data/restaurantData';

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenReservation: () => void;
}

const CHAPTERS = [
  { id: 'ember', title: 'I. The Philosophy of Ember', time: '00:00' },
  { id: 'kitchen', title: 'II. Master of the Wood-Fire', time: '01:14' },
  { id: 'skyline', title: 'III. Nightfall over the City', time: '02:45' },
];

export const VideoModal: React.FC<VideoModalProps> = ({
  isOpen,
  onClose,
  onOpenReservation,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [activeChapter, setActiveChapter] = useState('ember');

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/95 backdrop-blur-xl animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="video-modal-title"
    >
      <div className="relative w-full max-w-4xl bg-[#10100F] border border-[#79603A]/60 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        
        {/* Top bar */}
        <div className="px-6 py-4 bg-[#080807] border-b border-[#79603A]/25 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-[10px] uppercase tracking-[0.25em] text-[#D4AD68] font-medium">
              CINEMATIC DOCUMENTARY
            </span>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full border border-[#79603A]/40 flex items-center justify-center text-[#C5BFB5] hover:text-[#F5F0E8] hover:border-[#D4AD68] transition-colors focus-visible:outline-none"
            aria-label="Close video player"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video Canvas & Mock Atmospheric Player */}
        <div className="relative aspect-video bg-[#050505] overflow-hidden flex items-center justify-center group">
          <img
            src={ASSETS.storyInterior}
            alt="Ember & Spice documentary frame"
            className={`w-full h-full object-cover transition-transform duration-1000 ${
              isPlaying ? 'scale-105 filter brightness-95' : 'scale-100 filter brightness-75'
            }`}
          />

          {/* Film Grain & Cinematic Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 pointer-events-none" />

          {/* Center Play/Pause Overlay */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-16 h-16 rounded-full bg-[#080807]/75 border border-[#D4AD68] backdrop-blur-md flex items-center justify-center text-[#D4AD68] hover:scale-110 transition-transform cursor-pointer shadow-2xl"
            aria-label={isPlaying ? 'Pause video' : 'Play video'}
          >
            {isPlaying ? (
              <Pause className="w-6 h-6 fill-current" />
            ) : (
              <Play className="w-6 h-6 fill-current translate-x-0.5" />
            )}
          </button>

          {/* Sound & Status Floating Indicator */}
          <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between z-10 text-xs">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="p-2 rounded-full bg-black/60 border border-[#79603A]/40 text-[#C5BFB5] hover:text-[#D4AD68] transition-colors"
                aria-label={isMuted ? 'Unmute ambience' : 'Mute ambience'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <span className="text-[#F5F0E8] font-mono text-[11px]">
                {isPlaying ? '01:28 / 03:45' : 'Paused'}
              </span>
            </div>

            <div className="hidden sm:flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AD68]" />
              <span className="text-xs text-[#D4AD68]">4K HDR Director&apos;s Cut</span>
            </div>
          </div>
        </div>

        {/* Video Chapters & Reservation CTA */}
        <div className="p-6 bg-[#0c0c0b] border-t border-[#79603A]/25 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2 w-full sm:w-auto overflow-x-auto">
            {CHAPTERS.map((ch) => (
              <button
                key={ch.id}
                onClick={() => setActiveChapter(ch.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  activeChapter === ch.id
                    ? 'bg-[#1a1815] text-[#D4AD68] border border-[#D4AD68]/60'
                    : 'text-[#938C81] hover:text-[#C5BFB5]'
                }`}
              >
                {ch.title}
              </button>
            ))}
          </div>

          <button
            onClick={() => {
              onClose();
              onOpenReservation();
            }}
            className="w-full sm:w-auto px-6 py-2.5 bg-[#D4AD68] hover:bg-[#B88B47] text-[#080807] text-xs font-semibold uppercase tracking-wider rounded-full transition-all cursor-pointer shrink-0"
          >
            Experience It in Person
          </button>
        </div>

      </div>
    </div>
  );
};
