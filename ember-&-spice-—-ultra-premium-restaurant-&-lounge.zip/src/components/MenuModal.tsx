import React, { useState, useMemo } from 'react';
import { X, Search, Sparkles, ArrowRight, Utensils } from 'lucide-react';
import { EXTENDED_MENU, Dish } from '../data/restaurantData';
import { filterMenuItems } from '../utils/booking';

interface MenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDish: (dish: Dish) => void;
  onReserveWithDish: (dish: Dish) => void;
}

const CATEGORIES = [
  { id: 'all', label: 'All Offerings' },
  { id: 'steaks', label: "Chef's Cuts & Steaks" },
  { id: 'pastas', label: 'Artisanal Pastas' },
  { id: 'seafood', label: 'Ocean & Seafood' },
  { id: 'starters', label: 'Appetizers & Starters' },
  { id: 'desserts', label: 'Decadent Desserts' },
  { id: 'cocktails', label: 'Crafted Cocktails' },
];

export const MenuModal: React.FC<MenuModalProps> = ({
  isOpen,
  onClose,
  onSelectDish,
  onReserveWithDish,
}) => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDishes = useMemo(() => {
    return filterMenuItems(EXTENDED_MENU, searchQuery, activeCategory);
  }, [searchQuery, activeCategory]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="menu-modal-title"
    >
      <div className="relative w-full max-w-5xl bg-[#10100F] border border-[#79603A]/50 rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-[#79603A]/25 bg-[#080807] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-medium tracking-[0.25em] text-[#D4AD68] uppercase block">
              EMBER &amp; SPICE GASTRONOMY
            </span>
            <h2 id="menu-modal-title" className="text-2xl sm:text-3xl font-serif text-[#F5F0E8] mt-0.5">
              Full Culinary Menu
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                placeholder="Search dishes, ingredients..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#10100F] border border-[#79603A]/40 focus:border-[#D4AD68] rounded-full py-1.5 pl-8 pr-3 text-xs text-[#F5F0E8] placeholder-[#79603A] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68] w-48 sm:w-60"
              />
              <Search className="w-3.5 h-3.5 text-[#79603A] absolute left-2.5 top-1/2 -translate-y-1/2" />
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full border border-[#79603A]/40 flex items-center justify-center text-[#C5BFB5] hover:text-[#F5F0E8] hover:border-[#D4AD68] transition-colors focus-visible:outline-none"
              aria-label="Close menu dialog"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Category Pills / Filter Tabs */}
        <div className="px-6 py-3 border-b border-[#79603A]/20 bg-[#0c0c0b] overflow-x-auto scrollbar-none flex items-center gap-2">
          {CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#D4AD68] text-[#080807] font-semibold shadow-sm'
                    : 'text-[#C5BFB5] hover:text-[#F5F0E8] hover:bg-[#1a1815]'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Dishes Grid */}
        <div className="p-6 overflow-y-auto space-y-4">
          {filteredDishes.length === 0 ? (
            <div className="py-12 text-center text-[#938C81]">
              <Utensils className="w-8 h-8 mx-auto mb-2 text-[#79603A]" />
              <p className="text-sm">No dishes match your filter or search query.</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('all');
                }}
                className="mt-3 text-xs text-[#D4AD68] hover:underline"
              >
                Clear all filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredDishes.map((dish) => (
                <div
                  key={dish.id}
                  className="bg-[#0c0c0b] border border-[#79603A]/30 hover:border-[#D4AD68]/60 rounded-xl p-4 flex gap-4 transition-all duration-200 group"
                >
                  <img
                    src={dish.image}
                    alt={dish.name}
                    loading="lazy"
                    className="w-24 h-24 rounded-lg object-cover shrink-0 border border-[#79603A]/20"
                  />
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-serif text-lg text-[#F5F0E8] group-hover:text-[#D4AD68] transition-colors leading-tight">
                          {dish.name}
                        </h3>
                        <span className="font-serif text-base text-[#D4AD68] font-medium">
                          ${dish.price}
                        </span>
                      </div>
                      <p className="text-xs text-[#938C81] font-light mt-1 line-clamp-2">
                        {dish.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-[#79603A]/20 mt-2">
                      <button
                        onClick={() => {
                          onClose();
                          onSelectDish(dish);
                        }}
                        className="text-[11px] text-[#C5BFB5] hover:text-[#D4AD68] flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <span>Tasting Notes</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>

                      <button
                        onClick={() => {
                          onClose();
                          onReserveWithDish(dish);
                        }}
                        className="text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-full border border-[#B88B47]/50 text-[#D4AD68] hover:bg-[#D4AD68]/15 transition-all cursor-pointer"
                      >
                        Reserve
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer info banner */}
        <div className="px-6 py-3.5 bg-[#080807] border-t border-[#79603A]/25 flex flex-col sm:flex-row items-center justify-between text-xs text-[#938C81]">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AD68]" />
            All steaks carved from prime artisanal ranches; seasonal truffle sourced from Norcia.
          </span>
          <button
            onClick={onClose}
            className="text-[#D4AD68] hover:underline mt-2 sm:mt-0 font-medium"
          >
            Back to Overview
          </button>
        </div>

      </div>
    </div>
  );
};
