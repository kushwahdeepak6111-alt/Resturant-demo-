import React, { useRef } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { POPULAR_DISHES, Dish } from '../data/restaurantData';

interface PopularDishesProps {
  onOpenMenu: () => void;
  onSelectDish: (dish: Dish) => void;
}

export const PopularDishes: React.FC<PopularDishesProps> = ({
  onOpenMenu,
  onSelectDish,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const offset = direction === 'left' ? -320 : 320;
      scrollContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  return (
    <section
      id="menu"
      className="py-20 lg:py-24 bg-[#080807] border-b border-[#79603A]/25 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header Row */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-12 gap-6">
          <div className="max-w-xl">
            <span className="text-[10px] sm:text-xs font-medium uppercase tracking-[0.25em] text-[#D4AD68] block mb-2">
              OUR SIGNATURE
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#F5F0E8] tracking-tight mb-3">
              Popular Dishes
            </h2>
            <p className="text-sm sm:text-base text-[#C5BFB5] font-light leading-relaxed mb-6">
              A journey of flavours, from classic favourites to modern creations.
            </p>

            <button
              onClick={onOpenMenu}
              className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full border border-[#B88B47]/60 hover:border-[#D4AD68] text-xs font-medium uppercase tracking-wider text-[#F5F0E8] hover:bg-[#D4AD68]/10 transition-all duration-300 group cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
            >
              <span>View Full Menu</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#D4AD68] transition-transform duration-200 group-hover:translate-x-1" />
            </button>
          </div>

          {/* Carousel Arrows on top right */}
          <div className="flex items-center gap-3 self-end lg:self-auto">
            <button
              onClick={() => scroll('left')}
              className="w-10 h-10 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] hover:bg-[#10100F] transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
              aria-label="Previous dishes"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="w-10 h-10 rounded-full border border-[#79603A]/50 hover:border-[#D4AD68] flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] hover:bg-[#10100F] transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
              aria-label="Next dishes"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 4 Cards Grid / Horizontal Scroll for Mobile */}
        <div
          ref={scrollContainerRef}
          className="flex lg:grid lg:grid-cols-4 gap-6 overflow-x-auto lg:overflow-visible pb-4 lg:pb-0 scrollbar-none snap-x snap-mandatory"
        >
          {POPULAR_DISHES.map((dish) => (
            <div
              key={dish.id}
              onClick={() => onSelectDish(dish)}
              className="min-w-[280px] sm:min-w-[300px] lg:min-w-0 snap-start bg-[#10100F] border border-[#79603A]/30 hover:border-[#D4AD68]/70 rounded-xl overflow-hidden transition-all duration-300 hover:-translate-y-1 group flex flex-col cursor-pointer shadow-lg hover:shadow-[#D4AD68]/10"
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectDish(dish);
                }
              }}
              aria-label={`View details for ${dish.name}`}
            >
              {/* Dish Image */}
              <div className="relative aspect-square overflow-hidden bg-[#080807]">
                <img
                  src={dish.image}
                  alt={dish.name}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#10100F] via-transparent to-transparent opacity-80" />
              </div>

              {/* Dish Content */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-serif text-[#F5F0E8] group-hover:text-[#D4AD68] transition-colors mb-1.5">
                    {dish.name}
                  </h3>
                  <p className="text-xs text-[#938C81] leading-relaxed font-light mb-4 line-clamp-2">
                    {dish.description}
                  </p>
                </div>

                {/* Price and Circular Arrow Button Row */}
                <div className="flex items-center justify-between pt-3 border-t border-[#79603A]/20">
                  <span className="text-base font-serif font-medium text-[#D4AD68]">
                    ${dish.price}
                  </span>

                  <div className="w-8 h-8 rounded-full border border-[#79603A]/60 group-hover:border-[#D4AD68] group-hover:bg-[#D4AD68] flex items-center justify-center transition-all duration-300">
                    <ArrowRight className="w-3.5 h-3.5 text-[#C5BFB5] group-hover:text-[#080807] transition-colors" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
