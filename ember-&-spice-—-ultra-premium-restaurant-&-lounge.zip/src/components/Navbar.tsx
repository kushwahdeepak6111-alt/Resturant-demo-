import React, { useState, useEffect } from 'react';
import { Search, Calendar, Menu as MenuIcon, X } from 'lucide-react';
import { RESTAURANT_INFO } from '../data/restaurantData';

interface NavbarProps {
  onOpenReservation: () => void;
  onOpenSearch: () => void;
  onOpenMenu: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenReservation,
  onOpenSearch,
  onOpenMenu,
}) => {
  const [activeSection, setActiveSection] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);

      const sections = ['home', 'about', 'menu', 'gallery', 'reservation', 'contact'];
      for (const section of [...sections].reverse()) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 200) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Home', href: '#home' },
    { id: 'about', label: 'About', href: '#about' },
    { id: 'menu', label: 'Menu', href: '#menu' },
    { id: 'gallery', label: 'Gallery', href: '#gallery' },
    { id: 'reservation', label: 'Reservation', action: onOpenReservation },
    { id: 'contact', label: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#080807]/95 backdrop-blur-md border-b border-[#79603A]/30 py-3 shadow-2xl'
          : 'bg-gradient-to-b from-black/80 via-black/40 to-transparent py-5 border-b border-[#79603A]/20'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo & Wordmark */}
          <a
            href="#home"
            className="flex items-center gap-3 group focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
            aria-label="Ember & Spice Home"
          >
            {/* Elegant stylized flame logo in champagne gold */}
            <div className="relative w-8 h-8 flex items-center justify-center">
              <svg
                viewBox="0 0 32 32"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="w-7 h-7 text-[#D4AD68] transition-transform duration-300 group-hover:scale-105"
              >
                <path
                  d="M16 2C16 2 10 9 10 15C10 19.4183 13.5817 23 18 23C22.4183 23 26 19.4183 26 15C26 12 24.5 9.5 23 8C23 11 20.5 13 18.5 13C16.5 13 15 11 16 2Z"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M14 18C14 18 12 21 12 23C12 25.2091 13.7909 27 16 27C18.2091 27 20 25.2091 20 23C20 21.5 19 20 18 19C17 18 16 16.5 14 18Z"
                  fill="#D4AD68"
                  fillOpacity="0.4"
                  stroke="#D4AD68"
                  strokeWidth="1.2"
                />
              </svg>
            </div>

            <div className="flex flex-col">
              <span className="font-serif text-lg tracking-[0.2em] font-medium text-[#F5F0E8] leading-tight group-hover:text-[#D4AD68] transition-colors">
                {RESTAURANT_INFO.name.toUpperCase()}
              </span>
              <span className="text-[9px] tracking-[0.25em] text-[#B88B47] uppercase font-light -mt-0.5">
                {RESTAURANT_INFO.subline}
              </span>
            </div>
          </a>

          {/* Desktop Center Navigation */}
          <nav className="hidden md:flex items-center space-x-8" aria-label="Main Navigation">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              if (link.action) {
                return (
                  <button
                    key={link.id}
                    onClick={link.action}
                    className={`relative py-1 text-sm tracking-wide transition-colors duration-200 cursor-pointer ${
                      isActive ? 'text-[#F5F0E8]' : 'text-[#C5BFB5] hover:text-[#F5F0E8]'
                    }`}
                  >
                    {link.label}
                    {isActive && (
                      <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#D4AD68]" />
                    )}
                  </button>
                );
              }

              return (
                <a
                  key={link.id}
                  href={link.href}
                  onClick={(e) => {
                    if (link.id === 'menu') {
                      e.preventDefault();
                      const el = document.getElementById('menu');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className={`relative py-1 text-sm tracking-wide transition-colors duration-200 ${
                    isActive ? 'text-[#F5F0E8]' : 'text-[#C5BFB5] hover:text-[#F5F0E8]'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#D4AD68]" />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Right Action Icons: Search & Book a Table button */}
          <div className="flex items-center space-x-4">
            <button
              onClick={onOpenSearch}
              className="p-2 text-[#C5BFB5] hover:text-[#D4AD68] transition-colors rounded-full focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
              aria-label="Search menu and dining experiences"
            >
              <Search className="w-4 h-4 stroke-[1.75]" />
            </button>

            {/* Outlined gold pill button matching reference */}
            <button
              onClick={onOpenReservation}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 border border-[#B88B47]/60 hover:border-[#D4AD68] rounded-full text-xs font-medium tracking-wider uppercase text-[#F5F0E8] hover:bg-[#D4AD68]/10 transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AD68]"
            >
              <Calendar className="w-3.5 h-3.5 text-[#D4AD68]" />
              <span>Book a Table</span>
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#C5BFB5] hover:text-[#F5F0E8] transition-colors focus-visible:outline-none"
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#080807]/98 border-b border-[#79603A]/40 px-6 py-6 backdrop-blur-xl animate-in slide-in-from-top duration-200">
          <nav className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={link.href || '#'}
                onClick={(e) => {
                  if (link.action) {
                    e.preventDefault();
                    link.action();
                  }
                  setMobileMenuOpen(false);
                }}
                className="text-base text-[#C5BFB5] hover:text-[#D4AD68] py-2 border-b border-[#79603A]/15 font-serif tracking-wider"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenReservation();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 border border-[#B88B47] text-[#D4AD68] rounded-full text-xs uppercase tracking-widest font-medium hover:bg-[#B88B47]/10"
              >
                <Calendar className="w-4 h-4" />
                Book a Table
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
