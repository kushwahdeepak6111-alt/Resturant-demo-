import React, { useEffect, useCallback } from 'react';
import { X, ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { GALLERY_ITEMS, GalleryItem } from '../data/restaurantData';

interface GalleryLightboxProps {
  activeItem: GalleryItem | null;
  onClose: () => void;
  onSelectNext: () => void;
  onSelectPrev: () => void;
  onBookExperience: () => void;
}

export const GalleryLightbox: React.FC<GalleryLightboxProps> = ({
  activeItem,
  onClose,
  onSelectNext,
  onSelectPrev,
  onBookExperience,
}) => {
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!activeItem) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onSelectNext();
      if (e.key === 'ArrowLeft') onSelectPrev();
    },
    [activeItem, onClose, onSelectNext, onSelectPrev]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  if (!activeItem) return null;

  const currentIndex = GALLERY_ITEMS.findIndex((item) => item.id === activeItem.id);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="lightbox-title"
    >
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-5 right-5 z-20 w-10 h-10 rounded-full bg-black/60 border border-[#79603A]/50 flex items-center justify-center text-[#C5BFB5] hover:text-[#F5F0E8] hover:border-[#D4AD68] transition-colors focus-visible:outline-none"
        aria-label="Close photo viewer"
      >
        <X className="w-5 h-5" />
      </button>

      {/* Prev button */}
      <button
        onClick={onSelectPrev}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full bg-black/60 border border-[#79603A]/50 flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] hover:border-[#D4AD68] transition-all focus-visible:outline-none"
        aria-label="Previous photo"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      {/* Next button */}
      <button
        onClick={onSelectNext}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full bg-black/60 border border-[#79603A]/50 flex items-center justify-center text-[#C5BFB5] hover:text-[#D4AD68] hover:border-[#D4AD68] transition-all focus-visible:outline-none"
        aria-label="Next photo"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Main Image Container */}
      <div className="relative max-w-5xl w-full flex flex-col items-center">
        <div className="relative rounded-2xl overflow-hidden border border-[#79603A]/50 shadow-2xl bg-[#080807] max-h-[75vh] flex items-center justify-center">
          <img
            src={activeItem.image}
            alt={activeItem.title}
            className="max-h-[72vh] w-auto max-w-full object-contain"
          />
        </div>

        {/* Caption Row */}
        <div className="w-full mt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 px-2">
          <div>
            <div className="flex items-center gap-3">
              <span className="text-[10px] uppercase tracking-[0.25em] text-[#D4AD68] font-medium">
                {activeItem.category}
              </span>
              <span className="text-xs text-[#79603A]">
                {currentIndex + 1} of {GALLERY_ITEMS.length}
              </span>
            </div>
            <h2 id="lightbox-title" className="text-2xl font-serif text-[#F5F0E8] mt-0.5">
              {activeItem.title}
            </h2>
            <p className="text-xs text-[#C5BFB5] font-light mt-1 max-w-xl">
              {activeItem.description}
            </p>
          </div>

          <button
            onClick={() => {
              onClose();
              onBookExperience();
            }}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#D4AD68] hover:bg-[#B88B47] text-[#080807] text-xs font-semibold uppercase tracking-wider rounded-full transition-all shrink-0 cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Book This Setting</span>
          </button>
        </div>
      </div>
    </div>
  );
};
