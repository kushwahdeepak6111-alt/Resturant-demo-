import React from 'react';
import { X, ShieldCheck } from 'lucide-react';

interface LegalModalProps {
  type: 'privacy' | 'terms' | null;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  const isPrivacy = type === 'privacy';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-2xl bg-[#10100F] border border-[#79603A]/50 rounded-2xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 border-b border-[#79603A]/25 bg-[#080807] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-[#D4AD68]" />
            <h2 className="text-xl font-serif text-[#F5F0E8]">
              {isPrivacy ? 'Privacy Policy' : 'Terms & Conditions'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full border border-[#79603A]/30 flex items-center justify-center text-[#C5BFB5] hover:text-[#F5F0E8] transition-colors"
            aria-label="Close legal modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-[#C5BFB5] leading-relaxed font-light">
          {isPrivacy ? (
            <>
              <p>
                At Ember &amp; Spice Restaurant &amp; Lounge, we value your privacy and are committed to protecting personal data collected through table bookings, dining preferences, and newsletter subscriptions.
              </p>
              <h3 className="font-serif text-sm text-[#F5F0E8] font-normal pt-2">1. Information We Collect</h3>
              <p>
                We collect your name, contact phone number, email address, dietary restrictions, and special dining occasions when you place a reservation. We never sell or distribute your personal details to third-party marketers.
              </p>
              <h3 className="font-serif text-sm text-[#F5F0E8] font-normal pt-2">2. Dining &amp; Allergen Records</h3>
              <p>
                Allergen notices provided during reservation are handled strictly by our executive culinary brigade to ensure guest safety and tailored dining experiences.
              </p>
              <h3 className="font-serif text-sm text-[#F5F0E8] font-normal pt-2">3. Contact Us</h3>
              <p>
                If you have questions regarding your data or wish to cancel newsletter subscription, contact us directly at hello@emberandspice.com.
              </p>
            </>
          ) : (
            <>
              <p>
                Welcome to Ember &amp; Spice. By reserving a table or using our culinary services, you agree to the following terms and house policies.
              </p>
              <h3 className="font-serif text-sm text-[#F5F0E8] font-normal pt-2">1. Reservation &amp; Cancellation Policy</h3>
              <p>
                To provide an exceptional dining experience, we hold reserved tables for 15 minutes past the scheduled booking time. For parties of 6 or more, cancellations must be provided at least 24 hours prior.
              </p>
              <h3 className="font-serif text-sm text-[#F5F0E8] font-normal pt-2">2. Dress Code</h3>
              <p>
                Ember &amp; Spice embraces an elegant smart-casual to formal dining atmosphere. Athletic attire, beachwear, and flip-flops are not permitted in the Main Dining Room or Skyline Suite.
              </p>
              <h3 className="font-serif text-sm text-[#F5F0E8] font-normal pt-2">3. Sommelier Corkage</h3>
              <p>
                Guests wishing to enjoy special vintage bottles from their personal cellar may do so for a corkage fee of $45 per 750ml bottle, limited to two bottles per reservation.
              </p>
            </>
          )}
        </div>

        <div className="px-6 py-4 bg-[#080807] border-t border-[#79603A]/20 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#D4AD68] hover:bg-[#B88B47] text-[#080807] text-xs font-semibold uppercase tracking-wider rounded-full transition-colors"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
