import React from 'react';
import { Play, ArrowRight, Sparkles, Award, Flame } from 'lucide-react';
import { ASSETS } from '../data/restaurantData';

interface StorySectionProps {
  onOpenVideo: () => void;
  onOpenReservation: () => void;
}

export const StorySection: React.FC<StorySectionProps> = ({
  onOpenVideo,
  onOpenReservation,
}) => {
  return (
    <section
      id="about"
      className="py-20 lg:py-28 bg-[#080807] border-b border-[#79603A]/25 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Left Side: Large Restaurant Interior Photograph */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#79603A]/30 shadow-2xl bg-[#10100F] group">
              <img
                src={ASSETS.storyInterior}
                alt="Ember & Spice grand dining room overlooking sunset skyline with chandeliers"
                loading="lazy"
                className="w-full h-[400px] sm:h-[480px] lg:h-[540px] object-cover transition-transform duration-700 group-hover:scale-105"
              />

              {/* Gradient overlay for text readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />

              {/* Bottom-left callout: Handwritten script + Watch Video button */}
              <div className="absolute bottom-6 left-6 sm:bottom-8 sm:left-8 z-10">
                <div className="mb-3">
                  <span className="font-script text-3xl sm:text-4xl text-[#F5F0E8] drop-shadow-md block tracking-wide">
                    More than just a restaurant
                  </span>
                </div>

                <button
                  onClick={onOpenVideo}
                  className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-[#080807]/75 hover:bg-[#080807] border border-[#B88B47]/60 hover:border-[#D4AD68] backdrop-blur-md transition-all duration-300 group/btn cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
                  aria-label="Watch restaurant story video"
                >
                  <div className="w-7 h-7 rounded-full bg-[#D4AD68]/20 flex items-center justify-center border border-[#D4AD68] group-hover/btn:bg-[#D4AD68] transition-colors">
                    <Play className="w-3 h-3 text-[#D4AD68] group-hover/btn:text-[#080807] fill-current translate-x-0.5" />
                  </div>
                  <span className="text-xs uppercase tracking-widest text-[#F5F0E8] group-hover/btn:text-[#D4AD68] transition-colors font-medium">
                    Watch Video
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Side: Narrative Story & 3 Brand Values & Spices Flatlay */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <span className="text-[10px] sm:text-xs font-medium uppercase tracking-[0.25em] text-[#D4AD68] block mb-2">
              OUR STORY
            </span>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-normal text-[#F5F0E8] tracking-tight mb-5">
              The Ember &amp; Spice Experience
            </h2>

            <p className="text-sm sm:text-base text-[#C5BFB5] font-light leading-relaxed mb-8">
              Founded with a simple belief — great food brings people together. At Ember &amp; Spice,
              we blend traditional culinary techniques with modern creativity to deliver an unforgettable dining experience.
            </p>

            {/* 3 Compact Brand-Value Items */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10 pt-4 border-t border-[#79603A]/25">
              
              {/* Pillar 1 */}
              <div className="flex flex-col">
                <div className="w-8 h-8 rounded-full border border-[#D4AD68]/40 flex items-center justify-center text-[#D4AD68] mb-3">
                  <Sparkles className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-medium text-[#F5F0E8] mb-1">
                  Fresh Ingredients
                </h3>
                <p className="text-xs text-[#938C81] leading-relaxed">
                  Locally sourced &amp; seasonal
                </p>
              </div>

              {/* Pillar 2 */}
              <div className="flex flex-col">
                <div className="w-8 h-8 rounded-full border border-[#D4AD68]/40 flex items-center justify-center text-[#D4AD68] mb-3">
                  <Award className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-medium text-[#F5F0E8] mb-1">
                  Expert Chefs
                </h3>
                <p className="text-xs text-[#938C81] leading-relaxed">
                  World-class culinary team
                </p>
              </div>

              {/* Pillar 3 */}
              <div className="flex flex-col">
                <div className="w-8 h-8 rounded-full border border-[#D4AD68]/40 flex items-center justify-center text-[#D4AD68] mb-3">
                  <Flame className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-medium text-[#F5F0E8] mb-1">
                  Cozy Ambience
                </h3>
                <p className="text-xs text-[#938C81] leading-relaxed">
                  Perfect for every occasion
                </p>
              </div>
            </div>

            {/* CTA & Spices Tray Row matching reference */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
              <button
                onClick={onOpenReservation}
                className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full border border-[#B88B47]/60 hover:border-[#D4AD68] text-xs font-medium uppercase tracking-wider text-[#F5F0E8] hover:bg-[#D4AD68]/10 transition-all duration-300 group cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#D4AD68]"
              >
                <span>Our Story</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#D4AD68] transition-transform duration-200 group-hover:translate-x-1" />
              </button>

              {/* Flatlay spices tray matching reference right corner */}
              <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-xl overflow-hidden border border-[#79603A]/40 shadow-xl group">
                <img
                  src={ASSETS.storySpices}
                  alt="Organic culinary spices: star anise, cinnamon quills, peppercorns, and embers"
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
