export interface ReservationRequest {
  date: string;
  time: string;
  guests: number;
  seatingArea: 'main' | 'skyline' | 'chef' | 'lounge';
  fullName: string;
  email: string;
  phone: string;
  specialRequests?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export function validateEmail(email: string): boolean {
  if (!email || typeof email !== 'string') return false;
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email.trim());
}

export function validatePhone(phone: string): boolean {
  if (!phone || typeof phone !== 'string') return false;
  const digits = phone.replace(/\D/g, '');
  return digits.length >= 7;
}

export function validateReservation(data: Partial<ReservationRequest>): ValidationResult {
  const errors: Record<string, string> = {};

  if (!data.date) {
    errors.date = 'Please select a reservation date';
  }

  if (!data.time) {
    errors.time = 'Please select a preferred seating time';
  }

  if (!data.guests || data.guests < 1) {
    errors.guests = 'Party size must be at least 1 guest';
  } else if (data.guests > 12) {
    errors.guests = 'For parties larger than 12, please contact our private dining concierge directly';
  }

  if (!data.fullName || data.fullName.trim().length < 2) {
    errors.fullName = 'Please enter your full name';
  }

  if (!data.email || !validateEmail(data.email)) {
    errors.email = 'Please provide a valid email address';
  }

  if (!data.phone || !validatePhone(data.phone)) {
    errors.phone = 'Please provide a valid contact phone number';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

export function generateBookingReference(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let ref = 'ES-';
  for (let i = 0; i < 5; i++) {
    ref += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return ref;
}

export function formatReservationDateTime(dateStr: string, timeStr: string): string {
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const d = new Date(year, month, day);
      const formattedDate = d.toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
      return `${formattedDate} at ${timeStr}`;
    }
  } catch {
    // Fallback if parsing fails
  }
  return `${dateStr} at ${timeStr}`;
}

export function filterMenuItems<T extends { name: string; description: string; category: string; dietary?: string[] }>(
  items: T[],
  query: string,
  categoryFilter: string
): T[] {
  const q = query.trim().toLowerCase();
  return items.filter((item) => {
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    if (!matchesCategory) return false;
    if (!q) return true;
    return (
      item.name.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      (item.dietary && item.dietary.some((d) => d.toLowerCase().includes(q)))
    );
  });
}
