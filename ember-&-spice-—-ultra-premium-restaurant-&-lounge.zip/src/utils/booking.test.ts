import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateEmail,
  validatePhone,
  validateReservation,
  generateBookingReference,
  filterMenuItems,
} from './booking.ts';

test('validateEmail correctly handles valid and invalid emails', () => {
  assert.equal(validateEmail('guest@example.com'), true);
  assert.equal(validateEmail('sommelier.vip@domain.co.uk'), true);
  assert.equal(validateEmail('invalid-email'), false);
  assert.equal(validateEmail(''), false);
});

test('validatePhone correctly validates international and standard phone formats', () => {
  assert.equal(validatePhone('+1 (555) 123-4567'), true);
  assert.equal(validatePhone('1234567890'), true);
  assert.equal(validatePhone('123'), false);
  assert.equal(validatePhone(''), false);
});

test('validateReservation detects missing fields and passes full data', () => {
  const invalidResult = validateReservation({});
  assert.equal(invalidResult.isValid, false);
  assert.ok(invalidResult.errors.date);
  assert.ok(invalidResult.errors.fullName);

  const validResult = validateReservation({
    date: '2026-11-15',
    time: '19:30',
    guests: 4,
    seatingArea: 'skyline',
    fullName: 'Eleanor Vance',
    email: 'eleanor@example.com',
    phone: '+1 555-0199',
  });
  assert.equal(validResult.isValid, true);
  assert.equal(Object.keys(validResult.errors).length, 0);
});

test('generateBookingReference produces prefixed 8-char codes', () => {
  const ref = generateBookingReference();
  assert.ok(ref.startsWith('ES-'));
  assert.equal(ref.length, 8);
});

test('filterMenuItems filters by category and search keyword', () => {
  const sampleDishes = [
    { name: 'Wagyu Steak', description: 'Grilled to perfection', category: 'steaks', dietary: ['Gluten-Free'] },
    { name: 'Truffle Pasta', description: 'Rich cream and shaved truffles', category: 'pastas', dietary: ['Vegetarian'] },
    { name: 'Herb Salmon', description: 'Fresh wild catch', category: 'seafood', dietary: [] },
  ];

  const steaks = filterMenuItems(sampleDishes, '', 'steaks');
  assert.equal(steaks.length, 1);
  assert.equal(steaks[0].name, 'Wagyu Steak');

  const truffleQuery = filterMenuItems(sampleDishes, 'truffle', 'all');
  assert.equal(truffleQuery.length, 1);
  assert.equal(truffleQuery[0].name, 'Truffle Pasta');

  const glutenFreeQuery = filterMenuItems(sampleDishes, 'gluten-free', 'all');
  assert.equal(glutenFreeQuery.length, 1);
  assert.equal(glutenFreeQuery[0].name, 'Wagyu Steak');
});
